// print hello world
{
  print("hello world");
  int a = 5 + 5.5;
}
