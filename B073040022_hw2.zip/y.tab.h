/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    NEWLINE = 258,
    ASSIGN = 259,
    PLUS = 260,
    MINUS = 261,
    MUL = 262,
    DIV = 263,
    SEMICOLON = 264,
    COMMA = 265,
    LP = 266,
    RP = 267,
    L_BRACKET = 268,
    R_BRACKET = 269,
    L_CURLY = 270,
    R_CURLY = 271,
    LT = 272,
    LE = 273,
    EQ = 274,
    DPLUS = 275,
    DMINUS = 276,
    PTYPE = 277,
    ID = 278,
    NUMBER = 279,
    FIELDMOD = 280,
    STR = 281,
    NEW = 282,
    CLASS = 283,
    IF = 284,
    ELSE = 285,
    WHILE = 286,
    FOR = 287,
    RETURN = 288,
    MAIN = 289,
    PRINT = 290,
    READ = 291,
    VOID = 292
  };
#endif
/* Tokens.  */
#define NEWLINE 258
#define ASSIGN 259
#define PLUS 260
#define MINUS 261
#define MUL 262
#define DIV 263
#define SEMICOLON 264
#define COMMA 265
#define LP 266
#define RP 267
#define L_BRACKET 268
#define R_BRACKET 269
#define L_CURLY 270
#define R_CURLY 271
#define LT 272
#define LE 273
#define EQ 274
#define DPLUS 275
#define DMINUS 276
#define PTYPE 277
#define ID 278
#define NUMBER 279
#define FIELDMOD 280
#define STR 281
#define NEW 282
#define CLASS 283
#define IF 284
#define ELSE 285
#define WHILE 286
#define FOR 287
#define RETURN 288
#define MAIN 289
#define PRINT 290
#define READ 291
#define VOID 292

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 26 "B073040022.y"

    char strVal[256];

#line 135 "y.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
